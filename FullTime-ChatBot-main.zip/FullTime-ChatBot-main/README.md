Not finish, process integrate html,css,js to Vue
Chatbot is how it should look in the future
